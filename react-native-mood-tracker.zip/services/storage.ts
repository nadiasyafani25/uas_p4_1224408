import AsyncStorage from "@react-native-async-storage/async-storage"
import type { MoodEntry, JournalEntry, ReminderSettings } from "../types"

const MOODS_KEY = "nadiary_moods"
const JOURNAL_KEY = "nadiary_journal"
const REMINDERS_KEY = "nadiary_reminders"

export const StorageService = {
  // Mood entries
  async getMoodEntries(): Promise<MoodEntry[]> {
    try {
      const data = await AsyncStorage.getItem(MOODS_KEY)
      return data ? JSON.parse(data) : []
    } catch (error) {
      console.error("Error getting mood entries:", error)
      return []
    }
  },

  async addMoodEntry(entry: MoodEntry): Promise<void> {
    try {
      const entries = await this.getMoodEntries()
      entries.unshift(entry)
      await AsyncStorage.setItem(MOODS_KEY, JSON.stringify(entries))
    } catch (error) {
      console.error("Error adding mood entry:", error)
    }
  },

  async deleteMoodEntry(timestamp: string): Promise<void> {
    try {
      const entries = await this.getMoodEntries()
      const filtered = entries.filter((e) => e.timestamp !== timestamp)
      await AsyncStorage.setItem(MOODS_KEY, JSON.stringify(filtered))
    } catch (error) {
      console.error("Error deleting mood entry:", error)
    }
  },

  // Journal entries
  async getJournalEntries(): Promise<JournalEntry[]> {
    try {
      const data = await AsyncStorage.getItem(JOURNAL_KEY)
      return data ? JSON.parse(data) : []
    } catch (error) {
      console.error("Error getting journal entries:", error)
      return []
    }
  },

  async addJournalEntry(entry: JournalEntry): Promise<void> {
    try {
      const entries = await this.getJournalEntries()
      entries.unshift(entry)
      await AsyncStorage.setItem(JOURNAL_KEY, JSON.stringify(entries))
    } catch (error) {
      console.error("Error adding journal entry:", error)
    }
  },

  async updateJournalEntry(entry: JournalEntry): Promise<void> {
    try {
      const entries = await this.getJournalEntries()
      const index = entries.findIndex((e) => e.id === entry.id)
      if (index !== -1) {
        entries[index] = entry
        await AsyncStorage.setItem(JOURNAL_KEY, JSON.stringify(entries))
      }
    } catch (error) {
      console.error("Error updating journal entry:", error)
    }
  },

  async deleteJournalEntry(id: string): Promise<void> {
    try {
      const entries = await this.getJournalEntries()
      const filtered = entries.filter((e) => e.id !== id)
      await AsyncStorage.setItem(JOURNAL_KEY, JSON.stringify(filtered))
    } catch (error) {
      console.error("Error deleting journal entry:", error)
    }
  },

  // Reminder settings
  async getReminderSettings(): Promise<ReminderSettings> {
    try {
      const data = await AsyncStorage.getItem(REMINDERS_KEY)
      return data
        ? JSON.parse(data)
        : {
            enabled: true,
            time: "09:00",
            frequency: "daily",
          }
    } catch (error) {
      console.error("Error getting reminder settings:", error)
      return {
        enabled: true,
        time: "09:00",
        frequency: "daily",
      }
    }
  },

  async setReminderSettings(settings: ReminderSettings): Promise<void> {
    try {
      await AsyncStorage.setItem(REMINDERS_KEY, JSON.stringify(settings))
    } catch (error) {
      console.error("Error setting reminder settings:", error)
    }
  },

  // Export & Clear
  async exportData(): Promise<string> {
    try {
      const moods = await this.getMoodEntries()
      const journal = await this.getJournalEntries()
      return JSON.stringify({ moods, journal }, null, 2)
    } catch (error) {
      console.error("Error exporting data:", error)
      return ""
    }
  },

  async clearAllData(): Promise<void> {
    try {
      await AsyncStorage.multiRemove([MOODS_KEY, JOURNAL_KEY])
    } catch (error) {
      console.error("Error clearing data:", error)
    }
  },
}
