export interface MoodEntry {
  mood: string
  note: string
  timestamp: string
  tags?: string[]
  intensity?: number
}

export interface JournalEntry {
  id: string
  title: string
  content: string
  mood: string
  timestamp: string
  tags?: string[]
}

export interface ReminderSettings {
  enabled: boolean
  time: string
  frequency: "daily" | "weekly"
  daysOfWeek?: number[]
}

export interface MoodAnalytics {
  totalEntries: number
  moodCounts: Record<string, number>
  averageMoodTrend: Record<string, number>
  streakDays: number
}
