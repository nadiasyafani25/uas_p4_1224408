# NaDiary - Catatan Suasana Hati

Aplikasi React Native untuk mencatat dan melacak suasana hati harian. Membantu pengguna mengenali emosi, refleksi diri, dan menjaga kesehatan mental secara sederhana dan aman.

## Fitur Utama

### 1. Pencatatan Suasana Hati (Home Screen)
- Quick mood selection dengan 6 kategori emosi (Bahagia, Sedih, Cemas, Tenang, Marah, Biasa Saja)
- Penyimpanan data harian otomatis
- Lihat catatan terbaru langsung di home screen
- Catatan lengkap dengan intensitas emosi (1-10) dan deskripsi

### 2. Analitik & Statistik (Analytics Screen)
- Total catatan dan streak counter (hari berturut-turut)
- Distribusi suasana hati dalam bentuk grafik progress bar
- Tren mingguan untuk melihat pola emosi
- Suasana hati dominan dengan statistik pengulangan
- Ringkasan kesehatan mental mingguan

### 3. Jurnal Refleksi (Journal Screen)
- Tulis dan simpan refleksi diri panjang
- Search dan filter jurnal entries
- Organized dengan timestamp dan tags
- Delete entries dengan mudah
- Private dan aman (disimpan lokal)

### 4. Pengaturan & Reminder (Settings Screen)
- Setup notifikasi harian/mingguan otomatis
- Pilih jam pengingat yang sesuai
- Tes notifikasi untuk memastikan pengaturan bekerja
- Export data dalam format JSON
- Clear all data option

### 5. Data Persistence
- AsyncStorage untuk penyimpanan lokal
- Automatic backup dan save
- Export data kapan saja
- No internet required

## Stack Teknologi

- **Framework**: React Native 0.73 dengan Expo
- **Navigation**: Expo Router (File-based routing)
- **State Management**: React Hooks (useState, useCallback, useFocusEffect)
- **Storage**: @react-native-async-storage/async-storage
- **Notifications**: Expo Notifications
- **UI Components**: Expo Vector Icons + Custom Styling
- **Fonts**: Poppins (via Expo Fonts)
- **Language**: TypeScript

## Instalasi & Setup

### Prerequisites
- Node.js >= 16
- Expo CLI
- Android Studio (untuk development Android)

### Langkah Instalasi

```bash
# 1. Clone atau create project
npx create-expo-app NaDiary
cd NaDiary

# 2. Install dependencies
npm install

# 3. Install required packages
npm install expo-router expo-notifications @react-native-async-storage/async-storage expo-font @expo/vector-icons expo-splash-screen react-native-reanimated uuid

# 4. Start development server
npm start
```

### Running on Android

```bash
# Development dengan Expo Go
npm start
# Tekan 'a' untuk membuka di Android emulator atau Expo Go app

# Build APK production
eas build --platform android
```

## Struktur Project

```
NaDiary/
├── app/
│   ├── index.tsx                 # Entry point
│   ├── _layout.tsx               # Root layout dengan notification setup
│   ├── (tabs)/
│   │   ├── _layout.tsx          # Tab navigation
│   │   ├── home.tsx             # Mood tracking screen
│   │   ├── analytics.tsx        # Stats & analytics
│   │   ├── journal.tsx          # Journal entries
│   │   └── settings.tsx         # App settings
│   └── modals/
│       ├── add-entry.tsx        # Modal untuk detail mood entry
│       └── add-journal-entry.tsx # Modal untuk jurnal entry
│
├── hooks/
│   ├── useMoodData.ts           # Mood data management
│   ├── useJournalData.ts        # Journal data management
│   ├── useReminder.ts           # Legacy reminder hook
│   ├── useReminderSetup.ts      # Complete reminder setup
│   └── useNotifications.ts      # Notification handlers
│
├── services/
│   └── storage.ts               # AsyncStorage service
│
├── constants/
│   ├── moods.ts                 # Mood categories & emojis
│   └── theme.ts                 # Color palette & design tokens
│
├── types/
│   └── index.ts                 # TypeScript interfaces
│
├── assets/
│   ├── icon.png
│   ├── splash.png
│   ├── adaptive-icon.png
│   └── fonts/
│       ├── Poppins-Bold.ttf
│       ├── Poppins-Regular.ttf
│       └── Poppins-SemiBold.ttf
│
├── app.json                     # Expo configuration
├── package.json
├── tsconfig.json
└── README.md
```

## Fitur Detail

### Mood Categories
- **Bahagia** 😊 - Perasaan positif dan senang
- **Sedih** 😢 - Perasaan duka atau melankolis
- **Cemas** 😰 - Perasaan khawatir atau takut
- **Tenang** 😌 - Perasaan damai dan rileks
- **Marah** 😠 - Perasaan kesal atau frustrasi
- **Biasa Saja** 😐 - Perasaan netral

### Reminder System
- **Daily Reminder**: Notifikasi setiap hari pada jam yang ditentukan
- **Weekly Reminder**: Notifikasi setiap Senin untuk refleksi mingguan
- **Customizable**: Ubah jam dan frekuensi kapan saja
- **Test Notification**: Tombol untuk test notifikasi

### Data Export
- Export semua mood entries dan journal dalam format JSON
- Dapat digunakan untuk backup atau analisis lebih lanjut
- Data tetap aman di device

## Tips Penggunaan

1. **Konsisten Mencatat**: Catat suasana hati setiap hari untuk hasil analitik terbaik
2. **Refleksi Diri**: Gunakan journal untuk mendokumentasikan thoughts dan feelings yang lebih detail
3. **Review Tren**: Lihat analytics mingguan untuk mengenali pola emosi Anda
4. **Backup Data**: Secara berkala export data untuk keamanan

## Privacy & Security

- Semua data disimpan lokal di device (tidak ada cloud/server)
- Tidak ada tracking atau analytics yang dikirim
- 100% private dan offline first
- User punya kontrol penuh atas data mereka
- Dapat delete semua data kapan saja

## Troubleshooting

### Notifikasi tidak muncul
1. Pastikan permission notifikasi sudah diberikan
2. Coba "Tes Notifikasi" di settings
3. Periksa apakah reminder sudah enabled

### Data tidak tersimpan
1. Periksa apakah storage permission sudah diberikan
2. Coba restart aplikasi
3. Clear app data dan setup ulang

### Reminder tidak trigger
1. Pastikan device tidak dalam Do Not Disturb mode
2. Periksa battery optimization settings
3. Tik kotak "Aktifkan Pengingat" di settings

## Development Roadmap

- [ ] Cloud sync dengan Supabase
- [ ] Dark mode support
- [ ] Sentiment analysis untuk mood entries
- [ ] Share mood insights
- [ ] Local database dengan SQLite untuk better performance
- [ ] Widget untuk quick mood logging
- [ ] Export ke PDF untuk jurnal
- [ ] Push notifications dengan custom sounds

## License

MIT License

## Support

Untuk pertanyaan atau issues, silakan buat issue di GitHub repository.

---

**NaDiary** - Dokumentasikan emosi Anda, kenali diri Anda lebih baik.
