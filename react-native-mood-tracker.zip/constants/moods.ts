export const MOOD_CATEGORIES = ["happy", "sad", "anxious", "calm", "angry", "neutral"]

export const MOODS = {
  happy: {
    label: "Bahagia",
    emoji: "😊",
    color: "#FFE5B4",
    rgb: { r: 255, g: 229, b: 180 },
  },
  sad: {
    label: "Sedih",
    emoji: "😢",
    color: "#B4D7FF",
    rgb: { r: 180, g: 215, b: 255 },
  },
  anxious: {
    label: "Cemas",
    emoji: "😰",
    color: "#FFD4D4",
    rgb: { r: 255, g: 212, b: 212 },
  },
  calm: {
    label: "Tenang",
    emoji: "😌",
    color: "#D4F4DD",
    rgb: { r: 212, g: 244, b: 221 },
  },
  angry: {
    label: "Marah",
    emoji: "😠",
    color: "#FFB4B4",
    rgb: { r: 255, g: 180, b: 180 },
  },
  neutral: {
    label: "Biasa Saja",
    emoji: "😐",
    color: "#E8E8E8",
    rgb: { r: 232, g: 232, b: 232 },
  },
}
