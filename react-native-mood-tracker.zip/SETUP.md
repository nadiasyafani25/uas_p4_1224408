# NaDiary - Panduan Setup & Installation

## Quick Start

### 1. Prerequisites
- Node.js 16+ dan npm
- Expo CLI (`npm install -g expo-cli`)
- Android Studio (untuk testing Android)
- atau Expo Go app di smartphone

### 2. Setup Project

```bash
# Clone atau create project
npx create-expo-app NaDiary
cd NaDiary

# Copy semua file dari struktur di atas

# Install dependencies
npm install
```

### 3. Run Development

```bash
# Start Expo dev server
npm start

# Untuk Android Emulator
npm run android

# Untuk Smartphone dengan Expo Go
# Scan QR code yang muncul di terminal
```

### 4. First Time Setup

Ketika app pertama kali dibuka:
1. Permissions akan diminta untuk notifications
2. Klik "Allow" untuk enable reminder notifications
3. Go to Settings tab untuk setup reminder time
4. Mulai catat mood Anda dengan klik salah satu mood di Home tab

## File Structure

```
NaDiary/
├── app/                          # Routing & screens
│   ├── index.tsx
│   ├── _layout.tsx
│   ├── (tabs)/
│   │   ├── _layout.tsx
│   │   ├── home.tsx
│   │   ├── analytics.tsx
│   │   ├── journal.tsx
│   │   └── settings.tsx
│   └── modals/
│       ├── add-entry.tsx
│       └── add-journal-entry.tsx
├── hooks/                        # Custom React hooks
│   ├── useMoodData.ts
│   ├── useJournalData.ts
│   ├── useReminderSetup.ts
│   └── useNotifications.ts
├── services/
│   └── storage.ts               # AsyncStorage management
├── constants/
│   ├── moods.ts
│   └── theme.ts
├── types/
│   └── index.ts
├── utils/                        # Utility functions
│   ├── test-data.ts             # Mock data for testing
│   ├── validation.ts            # Input validation
│   ├── analytics.ts             # Analytics calculations
│   └── export.ts                # Data export functions
├── assets/
│   ├── fonts/
│   └── icons/
├── app.json                      # Expo config
├── package.json
├── tsconfig.json
└── README.md
```

## Testing dengan Mock Data

### Option 1: Manual Testing
1. Buka app
2. Click beberapa mood di home screen
3. Tulis beberapa journal entries
4. Lihat statistics di analytics screen

### Option 2: Seed Test Data
Edit `app/_layout.tsx` untuk uncomment:

```typescript
// Uncomment ini untuk seed test data saat app pertama kali dibuka
// import { seedTestData } from '../utils/test-data'
// import { StorageService } from '../services/storage'
//
// useEffect(() => {
//   seedTestData(StorageService)
// }, [])
```

Kemudian restart app untuk load test data.

## Data Persistence

### AsyncStorage
- Semua data disimpan di device dengan AsyncStorage
- Automatic save setiap kali add/edit/delete
- No internet required
- Max ~10MB per app (cukup untuk ribuan entries)

### Backup & Export
1. Go to Settings > Manajemen Data
2. Click "Ekspor Data" untuk download JSON
3. Save file di cloud atau external storage
4. Gunakan untuk restore ke device lain

## Troubleshooting

### Notifikasi Tidak Muncul
```bash
# 1. Ensure permissions granted
# Go to Settings > Notifikasi > Allow

# 2. Test notification
Settings > Pengaturan Reminder > Tes Notifikasi

# 3. Check phone settings
# Phone Settings > Apps > NaDiary > Notifications > Allow
```

### Data Tidak Tersimpan
```bash
# Clear app cache
npm start -- --clear

# Atau di Android:
adb shell pm clear com.yourapp.nadiary
```

### Error: "Cannot find module"
```bash
# Reinstall dependencies
rm -rf node_modules
npm install
```

## Building for Production

### Android APK
```bash
# Build unsigned APK (untuk testing)
eas build --platform android --local

# Build signed APK (untuk production)
# Perlu setup EAS account
npm install -g eas-cli
eas build --platform android
```

### iOS
```bash
eas build --platform ios
```

## Environment Setup

### Android Studio Emulator
```bash
# List available devices
emulator -list-avds

# Start emulator
emulator -avd <device-name>

# Then run
npm run android
```

### Expo Go (Easiest)
1. Download Expo Go app dari Play Store
2. Run `npm start`
3. Scan QR code dengan Expo Go

## Development Tips

1. **Hot Reload**: Changes auto-reload saat save file
2. **Error Boundary**: Check console untuk error messages
3. **Debug**: Gunakan `console.log("[v0] ...")` untuk debug
4. **Network**: App sepenuhnya offline, tidak perlu internet

## Performance Optimization

- AsyncStorage queries sudah optimized dengan caching
- Analytics calculations dilakukan only when needed
- FlatList dengan scrollEnabled={false} untuk smooth rendering
- Memoization untuk expensive calculations

## Security

- Semua data stored locally di device
- Tidak ada user authentication (local only)
- Tidak ada cloud sync (privacy first)
- User punya kontrol penuh atas data

## Next Steps

1. Customize mood categories dan warna
2. Add custom reminder sounds
3. Implement cloud backup dengan Supabase
4. Add data visualization charts
5. Support untuk multiple users/profiles

---

Untuk bantuan lebih lanjut, lihat README.md atau issue di GitHub.
