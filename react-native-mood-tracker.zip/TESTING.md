# Testing Guide untuk NaDiary

## Unit Testing Setup

### Test Data
Gunakan file `utils/test-data.ts` untuk mock data:

```typescript
import { MOCK_MOOD_ENTRIES, MOCK_JOURNAL_ENTRIES } from '../utils/test-data'

// Test mood tracking
const testMood = MOCK_MOOD_ENTRIES[0]
console.log(testMood.mood) // 'happy'
console.log(testMood.intensity) // 9
```

## Manual Testing Checklist

### Home Screen
- [ ] Can select mood from 6 categories
- [ ] Today's mood displays correctly
- [ ] Recent entries show in list
- [ ] Can open add entry modal
- [ ] Can save mood with note
- [ ] Mood updates immediately

### Analytics Screen
- [ ] Total entries count is correct
- [ ] Streak counter works
- [ ] Mood distribution chart displays
- [ ] Weekly trend shows data
- [ ] Most frequent mood displays

### Journal Screen
- [ ] Can create new journal entry
- [ ] Can search/filter entries
- [ ] Can delete entries
- [ ] Entries persist after close
- [ ] Can see entry details

### Settings Screen
- [ ] Can toggle reminder on/off
- [ ] Can change reminder time
- [ ] Can select daily/weekly
- [ ] Test notification works
- [ ] Can export data
- [ ] Can clear all data

### Data Persistence
- [ ] Data saved after app close
- [ ] Data restored on app reopen
- [ ] Export produces valid JSON
- [ ] Multiple sessions sync data

## Performance Testing

### Memory Usage
```typescript
// Monitor memory with console logs
console.log('[v0] Mood entries loaded:', entries.length)
console.log('[v0] Memory estimate:', JSON.stringify(entries).length, 'bytes')
```

### Loading Time
```typescript
const start = Date.now()
await StorageService.getMoodEntries()
const duration = Date.now() - start
console.log('[v0] Load time:', duration, 'ms')
```

## Validation Testing

```typescript
import { validateMoodEntry, validateJournalEntry } from '../utils/validation'

// Valid mood entry
const validMood = {
  mood: 'happy',
  note: 'Test',
  timestamp: new Date().toISOString(),
  intensity: 5,
}
console.log(validateMoodEntry(validMood)) // []

// Invalid mood entry
const invalidMood = {
  mood: 'happy',
  note: 'Test',
  timestamp: new Date().toISOString(),
  intensity: 15, // Out of range
}
console.log(validateMoodEntry(invalidMood)) // ['Intensity must be between 1 and 10']
```

## Analytics Testing

```typescript
import { calculateMoodStats, calculateConsecutiveDays } from '../utils/analytics'

const entries = MOCK_MOOD_ENTRIES
const stats = calculateMoodStats(entries)

console.log('Total entries:', stats.totalEntries)
console.log('Average intensity:', stats.averageIntensity)
console.log('Mood distribution:', stats.moodDistribution)
console.log('Consecutive days:', calculateConsecutiveDays(entries))
```

## Integration Testing

### Test Complete Flow
1. Open app
2. Add 5 mood entries dengan intensitas berbeda
3. Check analytics untuk verifikasi stats
4. Add 2 journal entries
5. Export data dan verify JSON
6. Delete semua data
7. Verify app empty
8. Close dan reopen app
9. Verify truly empty

### Test Reminders
1. Set reminder untuk 1 menit dari sekarang
2. Wait dan verify notification appears
3. Tap notification dan verify navigate ke home
4. Change reminder time
5. Verify scheduled notification updated

## Troubleshooting Tests

### Test data tidak tampil
```bash
# Clear AsyncStorage
npm start -- --clear

# Or in code:
await AsyncStorage.clear()
```

### Inconsistent test results
- Pastikan setiap test clear data sebelum mulai
- Use timestamps yang konsisten
- Mock date jika perlu

### Performance issues
- Test dengan besar dataset (1000+ entries)
- Monitor console untuk errors
- Check memory usage

---

Lihat SETUP.md untuk environment setup instruksi.
