# NaDiary - Panduan Cepat

Ini adalah aplikasi **React Native dengan Expo** - bukan aplikasi web. Untuk menjalankannya, ikuti langkah di bawah.

## Instalasi (5 menit)

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm start

# 3. Buka di smartphone/emulator
# - Scan QR code dengan Expo Go app, ATAU
# - Tekan 'a' untuk Android emulator
# - Tekan 'i' untuk iOS simulator
```

## Fitur Utama

1. **Home Screen** - Catat suasana hati dengan 6 kategori emosi
2. **Analytics** - Lihat tren dan statistik mood Anda
3. **Journal** - Tulis refleksi diri dan jurnal pribadi
4. **Settings** - Setup reminder harian/mingguan + manage data
5. **Reminder System** - Notifikasi otomatis untuk mencatat mood

## Persyaratan

- Node.js 16+
- Expo CLI: `npm install -g expo-cli`
- Android Studio (untuk emulator) ATAU Expo Go app di smartphone

## Struktur App

```
Home (Tab 1)
├── Quick Mood Selection
├── Today's Mood Display
└── Recent Entries

Analytics (Tab 2)
├── Total Entries & Streaks
├── Mood Distribution Charts
└── Weekly Trends

Journal (Tab 3)
├── Create/Edit/Delete Entries
├── Search Functionality
└── Timestamps & Tags

Settings (Tab 4)
├── Reminder Configuration
├── Data Export/Import
└── App Information
```

## Testing dengan Mock Data

Untuk lihat app dengan data:
1. Buka `utils/test-data.ts`
2. Edit `app/_layout.tsx` - uncomment bagian seedTestData
3. Restart app

## Production Build

```bash
# Build untuk Android
npm run build-android

# Build untuk iOS
npm run build-ios
```

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Port 19000 sudah digunakan | `lsof -i :19000` then `kill -9 <PID>` |
| Notifikasi tidak muncul | Settings > Allow notifications untuk app |
| Data tidak tersimpan | Clear cache: `npm start -- --clear` |
| Module not found error | `rm -rf node_modules && npm install` |

## Dokumentasi Lengkap

- **SETUP.md** - Instalasi dan konfigurasi detail
- **TESTING.md** - Testing checklist dan contoh kode
- **README.md** - Dokumentasi lengkap fitur

---

**NaDiary siap digunakan! Start dengan `npm start`**
