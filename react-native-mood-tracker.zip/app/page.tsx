import { COLORS } from "../constants/theme"

export default function Page() {
  return (
    <div style={styles.container}>
      <div style={styles.content}>
        <h1 style={styles.title}>NaDiary</h1>
        <p style={styles.subtitle}>Catatan Suasana Hati - Mood Tracking App</p>

        <div style={styles.alert}>
          <p style={styles.alertTitle}>React Native Mobile App</p>
          <p style={styles.alertText}>
            NaDiary adalah aplikasi <strong>React Native dengan Expo</strong>, bukan aplikasi web. Aplikasi ini
            dijalankan di smartphone Android/iOS, bukan di browser.
          </p>
        </div>

        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Cara Menjalankan</h2>
          <ol style={styles.list}>
            <li>
              Pastikan dependencies sudah diinstall: <code style={styles.code}>npm install</code>
            </li>
            <li>
              Jalankan dev server: <code style={styles.code}>npm start</code>
            </li>
            <li>Buka di smartphone dengan Expo Go app (scan QR code)</li>
            <li>Atau tekan 'a' untuk Android emulator</li>
          </ol>
        </div>

        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Fitur Utama</h2>
          <ul style={styles.list}>
            <li>
              <strong>Home Screen</strong> - Catat suasana hati dengan 6 kategori emosi
            </li>
            <li>
              <strong>Analytics</strong> - Lihat tren dan statistik mood
            </li>
            <li>
              <strong>Journal</strong> - Tulis refleksi diri dan jurnal pribadi
            </li>
            <li>
              <strong>Settings</strong> - Setup reminder + manage data
            </li>
            <li>
              <strong>Reminder System</strong> - Notifikasi otomatis harian/mingguan
            </li>
          </ul>
        </div>

        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Tech Stack</h2>
          <ul style={styles.list}>
            <li>React Native 0.73 + Expo Router</li>
            <li>TypeScript untuk type safety</li>
            <li>AsyncStorage untuk data persistence</li>
            <li>Expo Notifications untuk reminders</li>
            <li>Tab navigation dengan 4 screens</li>
          </ul>
        </div>

        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Struktur Project</h2>
          <pre style={styles.pre}>{`app/
├── index.tsx              # Entry point
├── _layout.tsx            # Root layout
├── (tabs)/
│   ├── home.tsx           # Mood tracking
│   ├── analytics.tsx      # Statistics
│   ├── journal.tsx        # Reflections
│   └── settings.tsx       # Preferences
└── modals/
    ├── add-entry.tsx
    └── add-journal-entry.tsx

hooks/
├── useMoodData.ts
├── useJournalData.ts
├── useReminderSetup.ts
└── useNotifications.ts

services/
└── storage.ts             # AsyncStorage

constants/
├── moods.ts
└── theme.ts

types/
└── index.ts

utils/
├── test-data.ts
├── validation.ts
├── analytics.ts
└── export.ts`}</pre>
        </div>

        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Dokumentasi</h2>
          <ul style={styles.list}>
            <li>
              <strong>QUICKSTART.md</strong> - Panduan cepat (5 menit)
            </li>
            <li>
              <strong>SETUP.md</strong> - Instalasi dan konfigurasi detail
            </li>
            <li>
              <strong>TESTING.md</strong> - Testing checklist dan contoh
            </li>
            <li>
              <strong>README.md</strong> - Dokumentasi lengkap fitur
            </li>
          </ul>
        </div>

        <div style={styles.section}>
          <h2 style={styles.sectionTitle}>Persyaratan</h2>
          <ul style={styles.list}>
            <li>Node.js 16+</li>
            <li>
              Expo CLI: <code style={styles.code}>npm install -g expo-cli</code>
            </li>
            <li>Android Studio (untuk emulator) ATAU Expo Go app di smartphone</li>
          </ul>
        </div>

        <div style={styles.footer}>
          <p>
            Aplikasi ini fully functional dan production-ready. Semua fitur (mood tracking, analytics, journal,
            reminders, data persistence) sudah implemented.
          </p>
          <p style={styles.footerCTA}>
            Jalankan dengan: <strong>npm start</strong>
          </p>
        </div>
      </div>
    </div>
  )
}

const styles = {
  container: {
    minHeight: "100vh",
    backgroundColor: COLORS.background,
    color: COLORS.text,
    fontFamily: "'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto",
    padding: "20px",
  },
  content: {
    maxWidth: "900px",
    margin: "0 auto",
    lineHeight: 1.6,
  },
  title: {
    fontSize: "3em",
    fontWeight: "bold",
    color: COLORS.primary,
    marginBottom: "8px",
  },
  subtitle: {
    fontSize: "1.3em",
    color: COLORS.textSecondary,
    marginBottom: "24px",
  },
  alert: {
    backgroundColor: "#E8F4FF",
    borderLeft: `4px solid ${COLORS.primary}`,
    padding: "16px",
    borderRadius: "8px",
    marginBottom: "24px",
  },
  alertTitle: {
    fontWeight: "bold",
    color: COLORS.primary,
    marginBottom: "8px",
  },
  alertText: {
    color: COLORS.text,
    margin: 0,
  },
  section: {
    marginBottom: "28px",
  },
  sectionTitle: {
    fontSize: "1.5em",
    fontWeight: "bold",
    color: COLORS.text,
    marginBottom: "12px",
    borderBottom: `2px solid ${COLORS.lightGray}`,
    paddingBottom: "8px",
  },
  list: {
    marginLeft: "20px",
    color: COLORS.text,
  },
  code: {
    backgroundColor: COLORS.lightGray,
    padding: "2px 6px",
    borderRadius: "4px",
    fontFamily: "monospace",
    fontSize: "0.9em",
  },
  pre: {
    backgroundColor: COLORS.lightGray,
    padding: "16px",
    borderRadius: "8px",
    overflow: "auto",
    fontFamily: "monospace",
    fontSize: "0.85em",
  },
  footer: {
    backgroundColor: COLORS.white,
    padding: "20px",
    borderRadius: "8px",
    marginTop: "32px",
    borderLeft: `4px solid ${COLORS.success}`,
  },
  footerCTA: {
    fontSize: "1.1em",
    color: COLORS.primary,
  },
}
