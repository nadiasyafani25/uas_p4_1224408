"use client"

import { useState } from "react"
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, SafeAreaView } from "react-native"
import { useRouter } from "expo-router"
import { Ionicons } from "@expo/vector-icons"
import { useMoodData } from "../../hooks/useMoodData"
import { MOODS, MOOD_CATEGORIES } from "../../constants/moods"
import { COLORS } from "../../constants/theme"

export default function AddEntryModal() {
  const router = useRouter()
  const { addMood } = useMoodData()
  const [selectedMood, setSelectedMood] = useState<string>("happy")
  const [note, setNote] = useState("")
  const [intensity, setIntensity] = useState(5)

  const handleSave = async () => {
    await addMood({
      mood: selectedMood,
      note,
      timestamp: new Date().toISOString(),
      intensity,
    })
    router.back()
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="close" size={24} color={COLORS.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Catatan Lengkap</Text>
          <TouchableOpacity onPress={handleSave}>
            <Text style={styles.saveButton}>Simpan</Text>
          </TouchableOpacity>
        </View>

        {/* Mood Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Pilih Suasana Hati</Text>
          <View style={styles.moodGrid}>
            {MOOD_CATEGORIES.map((category) => (
              <TouchableOpacity
                key={category}
                style={[
                  styles.moodButton,
                  {
                    backgroundColor: MOODS[category as keyof typeof MOODS].color,
                    opacity: selectedMood === category ? 1 : 0.5,
                    borderWidth: selectedMood === category ? 2 : 0,
                    borderColor: COLORS.primary,
                  },
                ]}
                onPress={() => setSelectedMood(category)}
              >
                <Text style={styles.moodEmoji}>{MOODS[category as keyof typeof MOODS].emoji}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Intensity Slider */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Intensitas Emosi (1-10)</Text>
          <View style={styles.intensityContainer}>
            <Text style={styles.intensityValue}>{intensity}</Text>
            <View style={styles.sliderTrack}>
              <View style={[styles.sliderFill, { width: `${(intensity / 10) * 100}%` }]} />
            </View>
            <View style={styles.intensityLabels}>
              <Text style={styles.label}>Ringan</Text>
              <Text style={styles.label}>Berat</Text>
            </View>
            <View style={styles.sliderButtons}>
              {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
                <TouchableOpacity
                  key={num}
                  style={[
                    styles.sliderButton,
                    {
                      backgroundColor: intensity === num ? COLORS.primary : COLORS.lightGray,
                    },
                  ]}
                  onPress={() => setIntensity(num)}
                >
                  <Text
                    style={[
                      styles.sliderButtonText,
                      {
                        color: intensity === num ? COLORS.white : COLORS.text,
                      },
                    ]}
                  >
                    {num}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>

        {/* Note Input */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Catatan Refleksi (Opsional)</Text>
          <TextInput
            style={styles.textInput}
            placeholder="Apa yang kamu rasakan? Tuliskan refleksimu..."
            placeholderTextColor={COLORS.textSecondary}
            multiline
            numberOfLines={6}
            value={note}
            onChangeText={setNote}
            textAlignVertical="top"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  headerTitle: {
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
  saveButton: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.primary,
  },
  section: {
    paddingHorizontal: 20,
    marginVertical: 20,
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 12,
  },
  moodGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  moodButton: {
    width: "30%",
    aspectRatio: 1,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  moodEmoji: {
    fontSize: 32,
  },
  intensityContainer: {
    paddingHorizontal: 12,
    paddingVertical: 16,
    backgroundColor: COLORS.white,
    borderRadius: 12,
  },
  intensityValue: {
    fontSize: 32,
    fontFamily: "Poppins-Bold",
    color: COLORS.primary,
    textAlign: "center",
    marginBottom: 16,
  },
  sliderTrack: {
    height: 8,
    backgroundColor: COLORS.lightGray,
    borderRadius: 4,
    marginBottom: 12,
    overflow: "hidden",
  },
  sliderFill: {
    height: "100%",
    backgroundColor: COLORS.primary,
    borderRadius: 4,
  },
  intensityLabels: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  label: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  sliderButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    flexWrap: "wrap",
    gap: 6,
  },
  sliderButton: {
    width: "9%",
    aspectRatio: 1,
    borderRadius: 6,
    justifyContent: "center",
    alignItems: "center",
  },
  sliderButtonText: {
    fontSize: 11,
    fontFamily: "Poppins-SemiBold",
  },
  textInput: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    fontSize: 14,
    fontFamily: "Poppins-Regular",
    color: COLORS.text,
    borderWidth: 1,
    borderColor: COLORS.lightGray,
  },
})
