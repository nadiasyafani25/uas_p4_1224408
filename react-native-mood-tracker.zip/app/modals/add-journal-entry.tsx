"use client"

import { useState } from "react"
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput, SafeAreaView } from "react-native"
import { useRouter } from "expo-router"
import { Ionicons } from "@expo/vector-icons"
import { useJournalData } from "../../hooks/useJournalData"
import { COLORS } from "../../constants/theme"
import { v4 as uuidv4 } from "uuid"

export default function AddJournalEntryModal() {
  const router = useRouter()
  const { addEntry } = useJournalData()
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) {
      alert("Mohon isi judul dan isi jurnal")
      return
    }

    await addEntry({
      id: uuidv4(),
      title,
      content,
      mood: "neutral",
      timestamp: new Date().toISOString(),
    })
    router.back()
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="close" size={24} color={COLORS.text} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Jurnal Baru</Text>
          <TouchableOpacity onPress={handleSave}>
            <Text style={styles.saveButton}>Simpan</Text>
          </TouchableOpacity>
        </View>

        {/* Title Input */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Judul Jurnal</Text>
          <TextInput
            style={styles.titleInput}
            placeholder="Masukkan judul jurnal Anda..."
            placeholderTextColor={COLORS.textSecondary}
            value={title}
            onChangeText={setTitle}
          />
        </View>

        {/* Content Input */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Isi Jurnal</Text>
          <TextInput
            style={styles.contentInput}
            placeholder="Tuliskan refleksi, pemikiran, dan perasaan Anda di sini..."
            placeholderTextColor={COLORS.textSecondary}
            multiline
            numberOfLines={10}
            value={content}
            onChangeText={setContent}
            textAlignVertical="top"
          />
        </View>

        {/* Tips */}
        <View style={styles.tipsSection}>
          <View style={styles.tipsCard}>
            <Ionicons name="information-circle" size={20} color={COLORS.primary} style={{ marginRight: 12 }} />
            <Text style={styles.tipsText}>
              Tulis dengan jujur dan bebas. Jurnal ini adalah ruang aman untuk refleksi diri Anda.
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.lightGray,
  },
  headerTitle: {
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
  saveButton: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.primary,
  },
  section: {
    paddingHorizontal: 20,
    marginVertical: 16,
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 12,
  },
  titleInput: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    borderWidth: 1,
    borderColor: COLORS.lightGray,
  },
  contentInput: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    fontSize: 14,
    fontFamily: "Poppins-Regular",
    color: COLORS.text,
    borderWidth: 1,
    borderColor: COLORS.lightGray,
  },
  tipsSection: {
    paddingHorizontal: 20,
    marginVertical: 16,
  },
  tipsCard: {
    backgroundColor: "#E8F4FF",
    borderRadius: 12,
    padding: 16,
    flexDirection: "row",
    alignItems: "flex-start",
  },
  tipsText: {
    flex: 1,
    fontSize: 13,
    color: COLORS.text,
    fontFamily: "Poppins-Regular",
    lineHeight: 20,
  },
})
