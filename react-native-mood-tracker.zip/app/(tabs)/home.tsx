"use client"
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, FlatList, SafeAreaView } from "react-native"
import { useRouter } from "expo-router"
import { Ionicons } from "@expo/vector-icons"
import { useMoodData } from "../../hooks/useMoodData"
import { MOODS, MOOD_CATEGORIES } from "../../constants/moods"
import { COLORS } from "../../constants/theme"

export default function HomeScreen() {
  const router = useRouter()
  const { entries, addMood, getTodayMood } = useMoodData()
  const todayMood = getTodayMood()
  const recentEntries = entries.slice(0, 5)

  const handleMoodSelect = (mood: string) => {
    addMood({
      mood,
      note: "",
      timestamp: new Date().toISOString(),
    })
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Catatan Suasana Hati Anda</Text>
          <Text style={styles.subtitle}>Catat perasaan Anda hari ini untuk kesehatan mental</Text>
        </View>

        {/* Today's Mood Card */}
        <View style={styles.todayCard}>
          <Text style={styles.cardTitle}>Suasana Hati Hari Ini</Text>
          {todayMood ? (
            <View style={styles.moodDisplay}>
              <Text style={styles.moodEmoji}>{MOODS[todayMood as keyof typeof MOODS].emoji}</Text>
              <Text style={styles.moodText}>{MOODS[todayMood as keyof typeof MOODS].label}</Text>
            </View>
          ) : (
            <Text style={styles.noMoodText}>Belum ada catatan hari ini</Text>
          )}
        </View>

        {/* Mood Categories */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Pilih Suasana Hati Anda</Text>
          <View style={styles.moodGrid}>
            {MOOD_CATEGORIES.map((category) => (
              <TouchableOpacity
                key={category}
                style={[
                  styles.moodButton,
                  {
                    backgroundColor: MOODS[category as keyof typeof MOODS].color,
                  },
                ]}
                onPress={() => handleMoodSelect(category)}
              >
                <Text style={styles.moodButtonEmoji}>{MOODS[category as keyof typeof MOODS].emoji}</Text>
                <Text style={styles.moodButtonLabel}>{MOODS[category as keyof typeof MOODS].label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Add Detailed Entry Button */}
        <TouchableOpacity style={styles.addDetailButton} onPress={() => router.push("/modals/add-entry")}>
          <Ionicons name="add-circle" size={24} color={COLORS.white} />
          <Text style={styles.addDetailButtonText}>Tambah Catatan Lengkap</Text>
        </TouchableOpacity>

        {/* Recent Entries */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Catatan Terbaru</Text>
          {recentEntries.length > 0 ? (
            <FlatList
              data={recentEntries}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <View style={styles.entryCard}>
                  <View style={styles.entryHeader}>
                    <Text style={styles.entryEmoji}>{MOODS[item.mood as keyof typeof MOODS].emoji}</Text>
                    <View style={styles.entryInfo}>
                      <Text style={styles.entryMood}>{MOODS[item.mood as keyof typeof MOODS].label}</Text>
                      <Text style={styles.entryTime}>{new Date(item.timestamp).toLocaleDateString("id-ID")}</Text>
                    </View>
                  </View>
                  {item.note && (
                    <Text style={styles.entryNote} numberOfLines={2}>
                      {item.note}
                    </Text>
                  )}
                </View>
              )}
              keyExtractor={(item) => item.timestamp}
            />
          ) : (
            <Text style={styles.emptyText}>Mulai catat suasana hati Anda</Text>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: "Poppins-Bold",
    color: COLORS.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  todayCard: {
    marginHorizontal: 20,
    marginBottom: 24,
    backgroundColor: COLORS.white,
    borderRadius: 16,
    padding: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.textSecondary,
    marginBottom: 16,
  },
  moodDisplay: {
    alignItems: "center",
    justifyContent: "center",
  },
  moodEmoji: {
    fontSize: 48,
    marginBottom: 8,
  },
  moodText: {
    fontSize: 18,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
  noMoodText: {
    fontSize: 16,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
    textAlign: "center",
  },
  section: {
    marginBottom: 24,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 12,
  },
  moodGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  moodButton: {
    width: "48%",
    aspectRatio: 1,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  moodButtonEmoji: {
    fontSize: 32,
    marginBottom: 8,
  },
  moodButtonLabel: {
    fontSize: 12,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.white,
    textAlign: "center",
  },
  addDetailButton: {
    marginHorizontal: 20,
    marginBottom: 24,
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    paddingVertical: 14,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  addDetailButtonText: {
    color: COLORS.white,
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
  },
  entryCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  entryHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  entryEmoji: {
    fontSize: 24,
    marginRight: 12,
  },
  entryInfo: {
    flex: 1,
  },
  entryMood: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 4,
  },
  entryTime: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  entryNote: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  emptyText: {
    textAlign: "center",
    color: COLORS.textSecondary,
    fontSize: 14,
    fontFamily: "Poppins-Regular",
    marginVertical: 20,
  },
})
