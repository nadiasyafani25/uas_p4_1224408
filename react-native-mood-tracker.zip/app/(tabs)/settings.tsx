"use client"

import { useState, useEffect } from "react"
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Switch,
  TextInput,
  Alert,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { StorageService } from "../../services/storage"
import { useReminderSetup } from "../../hooks/useReminderSetup"
import { useNotifications } from "../../hooks/useNotifications"
import { COLORS } from "../../constants/theme"

export default function SettingsScreen() {
  const [reminderEnabled, setReminderEnabled] = useState(true)
  const [reminderTime, setReminderTime] = useState("09:00")
  const [frequency, setFrequency] = useState<"daily" | "weekly">("daily")
  const { setupReminders } = useReminderSetup()
  const { sendTestNotification } = useNotifications()

  useEffect(() => {
    loadSettings()
  }, [])

  const loadSettings = async () => {
    const settings = await StorageService.getReminderSettings()
    setReminderEnabled(settings.enabled)
    setReminderTime(settings.time)
    setFrequency(settings.frequency)
  }

  const saveSettings = async () => {
    await StorageService.setReminderSettings({
      enabled: reminderEnabled,
      time: reminderTime,
      frequency,
    })
    setupReminders()
  }

  const handleReminderToggle = (value: boolean) => {
    setReminderEnabled(value)
  }

  const handleTimeChange = (time: string) => {
    setReminderTime(time)
  }

  const handleExportData = async () => {
    try {
      const data = await StorageService.exportData()
      Alert.alert("Ekspor Berhasil", "Data telah berhasil diekspor. Simpan data ini di tempat aman.")
    } catch (error) {
      Alert.alert("Error", "Gagal mengekspor data")
    }
  }

  const handleClearData = () => {
    Alert.alert("Hapus Semua Data", "Apakah Anda yakin? Tindakan ini tidak dapat dibatalkan.", [
      { text: "Batal", onPress: () => {}, style: "cancel" },
      {
        text: "Hapus",
        onPress: async () => {
          await StorageService.clearAllData()
          Alert.alert("Berhasil", "Semua data telah dihapus")
        },
        style: "destructive",
      },
    ])
  }

  const handleTestReminder = async () => {
    try {
      await sendTestNotification()
      Alert.alert("Berhasil", "Notifikasi tes akan dikirim dalam 2 detik")
    } catch (error) {
      Alert.alert("Error", "Gagal mengirim notifikasi tes")
    }
  }

  useEffect(() => {
    saveSettings()
  }, [reminderEnabled, reminderTime, frequency])

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Pengaturan</Text>
          <Text style={styles.subtitle}>Kelola preferensi aplikasi Anda</Text>
        </View>

        {/* Reminder Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Pengingat Harian</Text>

          <View style={styles.settingItem}>
            <View>
              <Text style={styles.settingLabel}>Aktifkan Pengingat</Text>
              <Text style={styles.settingDescription}>Dapatkan notifikasi untuk mencatat suasana hati</Text>
            </View>
            <Switch
              value={reminderEnabled}
              onValueChange={handleReminderToggle}
              trackColor={{
                false: COLORS.lightGray,
                true: COLORS.primary,
              }}
              thumbColor={COLORS.white}
            />
          </View>

          {reminderEnabled && (
            <>
              <View style={styles.timeInputContainer}>
                <Text style={styles.settingLabel}>Jam Pengingat</Text>
                <View style={styles.timeInput}>
                  <TextInput
                    style={styles.timeInputField}
                    value={reminderTime}
                    onChangeText={handleTimeChange}
                    placeholder="HH:MM"
                    maxLength={5}
                  />
                  <Ionicons name="time" size={20} color={COLORS.primary} style={styles.timeIcon} />
                </View>
              </View>

              <View style={styles.frequencyContainer}>
                <Text style={styles.settingLabel}>Frekuensi</Text>
                <View style={styles.frequencyOptions}>
                  {["daily", "weekly"].map((option) => (
                    <TouchableOpacity
                      key={option}
                      style={[
                        styles.frequencyButton,
                        {
                          backgroundColor: frequency === option ? COLORS.primary : COLORS.lightGray,
                        },
                      ]}
                      onPress={() => setFrequency(option as "daily" | "weekly")}
                    >
                      <Text
                        style={[
                          styles.frequencyButtonText,
                          {
                            color: frequency === option ? COLORS.white : COLORS.text,
                          },
                        ]}
                      >
                        {option === "daily" ? "Harian" : "Mingguan"}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <TouchableOpacity style={styles.testButton} onPress={handleTestReminder}>
                <Ionicons name="notifications" size={18} color={COLORS.white} />
                <Text style={styles.testButtonText}>Tes Notifikasi Reminder</Text>
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* About */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tentang Aplikasi</Text>

          <View style={styles.aboutCard}>
            <View style={styles.aboutHeader}>
              <Text style={styles.appName}>NaDiary</Text>
              <Text style={styles.version}>v1.0.0</Text>
            </View>
            <Text style={styles.aboutDescription}>
              Catatan Suasana Hati - Aplikasi sederhana untuk mencatat dan melacak suasana hati Anda setiap hari
            </Text>
            <Text style={styles.aboutMission}>
              Membantu Anda mengenali emosi, refleksi diri, dan menjaga kesehatan mental dengan aman dan sederhana
            </Text>
          </View>
        </View>

        {/* Data Management */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Manajemen Data</Text>

          <TouchableOpacity style={styles.dataButton} onPress={handleExportData}>
            <View style={styles.dataButtonIcon}>
              <Ionicons name="download" size={20} color={COLORS.primary} />
            </View>
            <View style={styles.dataButtonContent}>
              <Text style={styles.dataButtonLabel}>Ekspor Data</Text>
              <Text style={styles.dataButtonDescription}>Unduh semua data Anda dalam format JSON</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.gray} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.dataButton} onPress={handleClearData}>
            <View style={[styles.dataButtonIcon, { backgroundColor: "#FFE5E5" }]}>
              <Ionicons name="trash" size={20} color={COLORS.danger} />
            </View>
            <View style={styles.dataButtonContent}>
              <Text style={styles.dataButtonLabel}>Hapus Semua Data</Text>
              <Text style={styles.dataButtonDescription}>Tindakan ini tidak dapat dibatalkan</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={COLORS.gray} />
          </TouchableOpacity>
        </View>

        {/* Support */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Dukungan</Text>

          <TouchableOpacity style={styles.supportButton}>
            <Ionicons name="help-circle-outline" size={20} color={COLORS.primary} />
            <Text style={styles.supportButtonText}>Pusat Bantuan</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.supportButton}>
            <Ionicons name="heart-outline" size={20} color={COLORS.primary} />
            <Text style={styles.supportButtonText}>Tentang Kesehatan Mental</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: "Poppins-Bold",
    color: COLORS.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 12,
  },
  settingItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: COLORS.white,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  settingLabel: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  timeInputContainer: {
    marginTop: 12,
  },
  timeInput: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: COLORS.white,
    borderRadius: 12,
    paddingHorizontal: 12,
    marginTop: 8,
    borderWidth: 1,
    borderColor: COLORS.lightGray,
  },
  timeInputField: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
  timeIcon: {
    marginLeft: 8,
  },
  frequencyContainer: {
    marginTop: 16,
  },
  frequencyOptions: {
    flexDirection: "row",
    gap: 12,
    marginTop: 8,
  },
  frequencyButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  frequencyButtonText: {
    fontFamily: "Poppins-SemiBold",
    fontSize: 12,
  },
  testButton: {
    backgroundColor: COLORS.primary,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginTop: 16,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  testButtonText: {
    color: COLORS.white,
    fontFamily: "Poppins-SemiBold",
    fontSize: 14,
  },
  aboutCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  aboutHeader: {
    marginBottom: 12,
  },
  appName: {
    fontSize: 20,
    fontFamily: "Poppins-Bold",
    color: COLORS.primary,
  },
  version: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
    marginTop: 4,
  },
  aboutDescription: {
    fontSize: 13,
    color: COLORS.text,
    fontFamily: "Poppins-Regular",
    lineHeight: 20,
    marginBottom: 8,
  },
  aboutMission: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
    lineHeight: 18,
    fontStyle: "italic",
  },
  dataButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: COLORS.white,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  dataButtonIcon: {
    width: 40,
    height: 40,
    borderRadius: 8,
    backgroundColor: "#E8F4FF",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  dataButtonContent: {
    flex: 1,
  },
  dataButtonLabel: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 4,
  },
  dataButtonDescription: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  supportButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: COLORS.white,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    gap: 12,
  },
  supportButtonText: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
})
