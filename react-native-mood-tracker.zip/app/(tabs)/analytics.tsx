"use client"

import { useMemo } from "react"
import { View, Text, ScrollView, StyleSheet, SafeAreaView } from "react-native"
import { useMoodData } from "../../hooks/useMoodData"
import { MOODS } from "../../constants/moods"
import { COLORS } from "../../constants/theme"

export default function AnalyticsScreen() {
  const { entries, getMoodStats, getWeeklyTrend } = useMoodData()
  const stats = getMoodStats()
  const weeklyTrend = getWeeklyTrend()

  const totalEntries = entries.length
  const moodCounts = stats

  const mostFrequentMood = useMemo(() => {
    if (Object.keys(moodCounts).length === 0) return null
    return Object.entries(moodCounts).sort(([, a], [, b]) => b - a)[0][0]
  }, [moodCounts])

  const consecutiveDays = useMemo(() => {
    let streak = 0
    const today = new Date()

    for (let i = 0; i < 365; i++) {
      const checkDate = new Date(today)
      checkDate.setDate(checkDate.getDate() - i)
      const dateStr = checkDate.toDateString()

      const hasEntry = entries.some((e) => new Date(e.timestamp).toDateString() === dateStr)

      if (hasEntry) {
        streak++
      } else {
        break
      }
    }
    return streak
  }, [entries])

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Analitik Suasana Hati</Text>
          <Text style={styles.subtitle}>Pantau tren emosi Anda selama berjalannya waktu</Text>
        </View>

        {/* Key Metrics */}
        <View style={styles.metricsGrid}>
          <View style={[styles.metricCard, { backgroundColor: "#FFE5B4" }]}>
            <Text style={styles.metricValue}>{totalEntries}</Text>
            <Text style={styles.metricLabel}>Total Catatan</Text>
          </View>

          <View style={[styles.metricCard, { backgroundColor: "#D4F4DD" }]}>
            <Text style={styles.metricValue}>{consecutiveDays}</Text>
            <Text style={styles.metricLabel}>Hari Berturut-turut</Text>
          </View>
        </View>

        {/* Most Frequent Mood */}
        {mostFrequentMood && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Suasana Hati Dominan</Text>
            <View style={styles.frequentMoodCard}>
              <Text style={styles.frequentMoodEmoji}>{MOODS[mostFrequentMood as keyof typeof MOODS].emoji}</Text>
              <View>
                <Text style={styles.frequentMoodLabel}>{MOODS[mostFrequentMood as keyof typeof MOODS].label}</Text>
                <Text style={styles.frequentMoodCount}>{moodCounts[mostFrequentMood]} kali catatan</Text>
              </View>
            </View>
          </View>
        )}

        {/* Mood Distribution */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Distribusi Suasana Hati</Text>
          {Object.entries(moodCounts).map(([mood, count]) => (
            <View key={mood} style={styles.moodBarItem}>
              <View style={styles.moodBarLabel}>
                <Text style={styles.moodBarEmoji}>{MOODS[mood as keyof typeof MOODS].emoji}</Text>
                <Text style={styles.moodBarName}>{MOODS[mood as keyof typeof MOODS].label}</Text>
              </View>
              <View style={styles.moodBarContainer}>
                <View
                  style={[
                    styles.moodBar,
                    {
                      width: `${totalEntries > 0 ? (count / totalEntries) * 100 : 0}%`,
                      backgroundColor: MOODS[mood as keyof typeof MOODS].color,
                    },
                  ]}
                />
              </View>
              <Text style={styles.moodBarCount}>{count}</Text>
            </View>
          ))}
        </View>

        {/* Weekly Trend */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tren Mingguan</Text>
          <View style={styles.weeklyGrid}>
            {Object.entries(weeklyTrend).map(([date, data]: any) => (
              <View key={date} style={styles.dayCard}>
                <Text style={styles.dayLabel}>{data.date.split(",")[0]}</Text>
                <View style={styles.dayBar}>
                  <View style={[styles.dayBarFill, { height: `${Math.min(data.count * 20, 100)}%` }]} />
                </View>
                <Text style={styles.dayCount}>{data.count}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Stats Summary */}
        <View style={styles.section}>
          <View style={styles.summaryCard}>
            <Text style={styles.summaryTitle}>Ringkasan Kesehatan Mental</Text>
            <Text style={styles.summaryText}>
              Anda telah mencatat suasana hati Anda <Text style={styles.summaryBold}>{totalEntries} kali</Text> dengan
              konsistensi <Text style={styles.summaryBold}>{consecutiveDays} hari</Text> berturut-turut. Terus
              pertahankan kebiasaan baik ini untuk kesehatan mental Anda!
            </Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 16,
  },
  title: {
    fontSize: 24,
    fontFamily: "Poppins-Bold",
    color: COLORS.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  metricsGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    marginBottom: 24,
    gap: 12,
  },
  metricCard: {
    flex: 1,
    paddingVertical: 20,
    paddingHorizontal: 16,
    borderRadius: 12,
    alignItems: "center",
  },
  metricValue: {
    fontSize: 32,
    fontFamily: "Poppins-Bold",
    color: COLORS.text,
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 12,
    fontFamily: "Poppins-Regular",
    color: COLORS.text,
  },
  section: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 12,
  },
  frequentMoodCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    gap: 12,
  },
  frequentMoodEmoji: {
    fontSize: 40,
  },
  frequentMoodLabel: {
    fontSize: 16,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 4,
  },
  frequentMoodCount: {
    fontSize: 12,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
  },
  moodBarItem: {
    marginBottom: 16,
  },
  moodBarLabel: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  moodBarEmoji: {
    fontSize: 20,
    marginRight: 8,
  },
  moodBarName: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
  moodBarContainer: {
    flex: 1,
    height: 24,
    backgroundColor: COLORS.lightGray,
    borderRadius: 12,
    overflow: "hidden",
  },
  moodBar: {
    height: "100%",
    borderRadius: 12,
  },
  moodBarCount: {
    fontSize: 12,
    fontFamily: "Poppins-Regular",
    color: COLORS.textSecondary,
    marginTop: 4,
  },
  weeklyGrid: {
    flexDirection: "row",
    justifyContent: "space-between",
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 12,
  },
  dayCard: {
    flex: 1,
    alignItems: "center",
    marginHorizontal: 4,
  },
  dayLabel: {
    fontSize: 11,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 8,
  },
  dayBar: {
    width: "100%",
    height: 60,
    backgroundColor: COLORS.lightGray,
    borderRadius: 6,
    justifyContent: "flex-end",
    alignItems: "center",
    marginBottom: 8,
    overflow: "hidden",
  },
  dayBarFill: {
    width: "100%",
    backgroundColor: COLORS.primary,
  },
  dayCount: {
    fontSize: 12,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
  summaryCard: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    padding: 16,
    borderLeftWidth: 4,
    borderLeftColor: COLORS.primary,
  },
  summaryTitle: {
    fontSize: 14,
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
    marginBottom: 8,
  },
  summaryText: {
    fontSize: 13,
    color: COLORS.textSecondary,
    fontFamily: "Poppins-Regular",
    lineHeight: 20,
  },
  summaryBold: {
    fontFamily: "Poppins-SemiBold",
    color: COLORS.text,
  },
})
