"use client"

import "react-native-reanimated"
import { useEffect } from "react"
import { Stack } from "expo-router"
import * as SplashScreen from "expo-splash-screen"
import * as Notifications from "expo-notifications"
import { useFonts } from "expo-font"
import { useReminderSetup } from "../hooks/useReminderSetup"
import { useNotifications } from "../hooks/useNotifications"

SplashScreen.preventAutoHideAsync()

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    "Poppins-Bold": require("../assets/fonts/Poppins-Bold.ttf"),
    "Poppins-Regular": require("../assets/fonts/Poppins-Regular.ttf"),
    "Poppins-SemiBold": require("../assets/fonts/Poppins-SemiBold.ttf"),
  })

  useReminderSetup()
  useNotifications()

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: true,
      }),
    })
  }, [])

  if (!fontsLoaded) {
    return null
  }

  SplashScreen.hideAsync()

  return (
    <Stack
      screenOptions={{
        headerShown: false,
        animationEnabled: true,
      }}
    >
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      <Stack.Screen
        name="modals/add-entry"
        options={{
          presentation: "modal",
          animationEnabled: true,
        }}
      />
      <Stack.Screen
        name="modals/add-journal-entry"
        options={{
          presentation: "modal",
          animationEnabled: true,
        }}
      />
    </Stack>
  )
}
