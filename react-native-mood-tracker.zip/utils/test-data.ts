import type { MoodEntry, JournalEntry } from "../types"

export const MOCK_MOOD_ENTRIES: MoodEntry[] = [
  {
    mood: "happy",
    note: "Hari yang sangat bagus! Berhasil menyelesaikan project penting di pekerjaan.",
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 9,
  },
  {
    mood: "calm",
    note: "Hari biasa, tapi cukup rileks. Sempat yoga pagi.",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 7,
  },
  {
    mood: "anxious",
    note: "Cemas tentang presentasi minggu depan.",
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 6,
  },
  {
    mood: "sad",
    note: "Hari yang lumayan sedih, banyak pikiran.",
    timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 5,
  },
  {
    mood: "happy",
    note: "Liburan bersama keluarga, very fun!",
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 10,
  },
  {
    mood: "neutral",
    note: "Hari kerja normal, nothing special.",
    timestamp: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 5,
  },
  {
    mood: "calm",
    note: "Produktif dan fokus, senang dengan pencapaian hari ini.",
    timestamp: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    intensity: 8,
  },
]

export const MOCK_JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: "1",
    title: "Refleksi Minggu Ini",
    content:
      "Minggu ini sangat produktif. Saya berhasil menyelesaikan beberapa task yang sudah lama pending. Merasa senang karena bisa berkontribusi lebih banyak di tim. Namun di akhir minggu mulai terasa lelah dan stress mulai naik sedikit. Perlu lebih banyak istirahat.",
    mood: "happy",
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ["work", "productivity", "stress"],
  },
  {
    id: "2",
    title: "Self Care Day",
    content:
      "Hari ini saya putuskan untuk me-time. Sempat yoga pagi, minum kopi yang nikmat, baca buku favorit, dan jalan santai di taman. Rasanya benar-benar refresh. Mental health saya meningkat drastis setelah me-time ini. Akan saya lakukan ini setiap minggu.",
    mood: "calm",
    timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ["self-care", "wellness", "mental-health"],
  },
  {
    id: "3",
    title: "Pembelajaran Baru",
    content:
      "Mulai belajar React Native minggu ini. Awalnya terasa overwhelming dengan banyak konsep baru, tapi setelah beberapa hari latihan, mulai paham. Excited untuk terus belajar dan membuat aplikasi yang bermanfaat.",
    mood: "happy",
    timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    tags: ["learning", "programming", "growth"],
  },
]

export const seedTestData = async (StorageService: any) => {
  try {
    for (const entry of MOCK_MOOD_ENTRIES) {
      await StorageService.addMoodEntry(entry)
    }
    for (const entry of MOCK_JOURNAL_ENTRIES) {
      await StorageService.addJournalEntry(entry)
    }
    console.log("[v0] Test data seeded successfully")
  } catch (error) {
    console.error("[v0] Error seeding test data:", error)
  }
}
