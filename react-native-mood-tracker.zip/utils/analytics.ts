import type { MoodEntry } from "../types"

export const calculateMoodStats = (entries: MoodEntry[]) => {
  const stats = {
    totalEntries: entries.length,
    averageIntensity: entries.length > 0 ? entries.reduce((sum, e) => sum + (e.intensity || 5), 0) / entries.length : 0,
    moodDistribution: {} as Record<string, number>,
    dailyAverage: 0,
  }

  // Calculate mood distribution
  entries.forEach((entry) => {
    stats.moodDistribution[entry.mood] = (stats.moodDistribution[entry.mood] || 0) + 1
  })

  // Calculate daily average
  if (entries.length > 0) {
    const daysSpan = Math.ceil(
      (new Date(entries[0].timestamp).getTime() - new Date(entries[entries.length - 1].timestamp).getTime()) /
        (1000 * 60 * 60 * 24),
    )
    stats.dailyAverage = daysSpan > 0 ? entries.length / daysSpan : entries.length
  }

  return stats
}

export const getMoodTrend = (entries: MoodEntry[], days = 7) => {
  const trend: Record<string, number[]> = {}

  // Initialize trend for each day
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date()
    date.setDate(date.getDate() - i)
    const dateKey = date.toDateString()

    const dayEntries = entries.filter((e) => new Date(e.timestamp).toDateString() === dateKey)
    const avgIntensity =
      dayEntries.length > 0 ? dayEntries.reduce((sum, e) => sum + (e.intensity || 5), 0) / dayEntries.length : 0

    dayEntries.forEach((e) => {
      if (!trend[e.mood]) {
        trend[e.mood] = new Array(days).fill(0)
      }
      trend[e.mood][days - 1 - i] += avgIntensity / dayEntries.length
    })
  }

  return trend
}

export const calculateConsecutiveDays = (entries: MoodEntry[]): number => {
  if (entries.length === 0) return 0

  let streak = 0
  const today = new Date()

  for (let i = 0; i < 365; i++) {
    const checkDate = new Date(today)
    checkDate.setDate(checkDate.getDate() - i)
    const dateStr = checkDate.toDateString()

    const hasEntry = entries.some((e) => new Date(e.timestamp).toDateString() === dateStr)

    if (hasEntry) {
      streak++
    } else {
      break
    }
  }

  return streak
}
