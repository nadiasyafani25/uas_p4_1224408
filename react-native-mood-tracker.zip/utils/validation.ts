import type { MoodEntry, JournalEntry } from "../types"

export const validateMoodEntry = (entry: MoodEntry): string[] => {
  const errors: string[] = []

  if (!entry.mood) {
    errors.push("Mood is required")
  }

  if (!entry.timestamp) {
    errors.push("Timestamp is required")
  }

  if (entry.intensity && (entry.intensity < 1 || entry.intensity > 10)) {
    errors.push("Intensity must be between 1 and 10")
  }

  return errors
}

export const validateJournalEntry = (entry: JournalEntry): string[] => {
  const errors: string[] = []

  if (!entry.title || entry.title.trim().length === 0) {
    errors.push("Title is required")
  }

  if (entry.title && entry.title.length > 100) {
    errors.push("Title must be less than 100 characters")
  }

  if (!entry.content || entry.content.trim().length === 0) {
    errors.push("Content is required")
  }

  if (!entry.timestamp) {
    errors.push("Timestamp is required")
  }

  if (!entry.id) {
    errors.push("ID is required")
  }

  return errors
}

export const isMoodEntryValid = (entry: MoodEntry): boolean => {
  return validateMoodEntry(entry).length === 0
}

export const isJournalEntryValid = (entry: JournalEntry): boolean => {
  return validateJournalEntry(entry).length === 0
}
