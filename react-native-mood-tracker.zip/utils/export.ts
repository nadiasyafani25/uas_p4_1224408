import type { MoodEntry, JournalEntry } from "../types"

export const exportToJSON = (moods: MoodEntry[], journals: JournalEntry[]) => {
  const data = {
    exportDate: new Date().toISOString(),
    version: "1.0.0",
    moods,
    journals,
    statistics: {
      totalMoodEntries: moods.length,
      totalJournalEntries: journals.length,
    },
  }

  return JSON.stringify(data, null, 2)
}

export const exportToCSV = (moods: MoodEntry[]) => {
  const headers = ["Date", "Mood", "Intensity", "Note"]
  const rows = moods.map((entry) => [
    new Date(entry.timestamp).toLocaleDateString("id-ID"),
    entry.mood,
    entry.intensity || 5,
    `"${entry.note || ""}"`,
  ])

  const csv = [headers, ...rows].map((row) => row.join(",")).join("\n")

  return csv
}

export const downloadJSON = (data: string, filename = "nadiary-export.json") => {
  // This would be used in a web context
  // For React Native, we would use a different approach
  console.log("[v0] Export data:", data)
}
