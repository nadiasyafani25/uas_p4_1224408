"use client"

import { useState, useCallback } from "react"
import { useFocusEffect } from "expo-router"
import type { MoodEntry } from "../types"
import { StorageService } from "../services/storage"

export const useMoodData = () => {
  const [entries, setEntries] = useState<MoodEntry[]>([])
  const [loading, setLoading] = useState(true)

  useFocusEffect(
    useCallback(() => {
      loadEntries()
    }, []),
  )

  const loadEntries = async () => {
    setLoading(true)
    const data = await StorageService.getMoodEntries()
    setEntries(data)
    setLoading(false)
  }

  const addMood = useCallback(async (mood: MoodEntry) => {
    await StorageService.addMoodEntry(mood)
    await loadEntries()
  }, [])

  const deleteMood = useCallback(async (timestamp: string) => {
    await StorageService.deleteMoodEntry(timestamp)
    await loadEntries()
  }, [])

  const getTodayMood = useCallback(() => {
    const today = new Date().toDateString()
    const todayEntry = entries.find((e) => new Date(e.timestamp).toDateString() === today)
    return todayEntry?.mood
  }, [entries])

  const getMoodStats = useCallback(() => {
    const stats: Record<string, number> = {}
    entries.forEach((entry) => {
      stats[entry.mood] = (stats[entry.mood] || 0) + 1
    })
    return stats
  }, [entries])

  const getWeeklyTrend = useCallback(() => {
    const weekData: Record<string, any> = {}
    const today = new Date()

    for (let i = 6; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      const dateStr = date.toDateString()

      const dayEntries = entries.filter((e) => new Date(e.timestamp).toDateString() === dateStr)

      weekData[dateStr] = {
        date: date.toLocaleDateString("id-ID", {
          weekday: "short",
          month: "short",
          day: "numeric",
        }),
        count: dayEntries.length,
        moods: dayEntries.map((e) => e.mood),
      }
    }

    return weekData
  }, [entries])

  return {
    entries,
    loading,
    addMood,
    deleteMood,
    getTodayMood,
    getMoodStats,
    getWeeklyTrend,
  }
}
