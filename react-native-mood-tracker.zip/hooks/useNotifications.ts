"use client"

import { useEffect } from "react"
import * as Notifications from "expo-notifications"
import { useRouter } from "expo-router"

export const useNotifications = () => {
  const router = useRouter()

  useEffect(() => {
    // Handle notification when app is in foreground
    const subscription = Notifications.addNotificationReceivedListener((notification) => {
      console.log("[v0] Notification received:", notification)
    })

    // Handle notification tap
    const responseSubscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const { type } = response.notification.request.content.data
      if (type === "mood_reminder") {
        router.push("/(tabs)/home")
      }
    })

    return () => {
      subscription.remove()
      responseSubscription.remove()
    }
  }, [router])

  const sendTestNotification = async () => {
    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title: "Tes Notifikasi",
          body: "Ini adalah notifikasi tes dari NaDiary",
          data: { type: "test" },
        },
        trigger: { seconds: 2 },
      })
    } catch (error) {
      console.error("Error sending test notification:", error)
    }
  }

  return { sendTestNotification }
}
