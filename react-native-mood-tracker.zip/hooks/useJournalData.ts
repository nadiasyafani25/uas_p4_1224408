"use client"

import { useState, useCallback } from "react"
import { useFocusEffect } from "expo-router"
import type { JournalEntry } from "../types"
import { StorageService } from "../services/storage"

export const useJournalData = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([])
  const [loading, setLoading] = useState(true)

  useFocusEffect(
    useCallback(() => {
      loadEntries()
    }, []),
  )

  const loadEntries = async () => {
    setLoading(true)
    const data = await StorageService.getJournalEntries()
    setEntries(data)
    setLoading(false)
  }

  const addEntry = useCallback(async (entry: JournalEntry) => {
    await StorageService.addJournalEntry(entry)
    await loadEntries()
  }, [])

  const updateEntry = useCallback(async (entry: JournalEntry) => {
    await StorageService.updateJournalEntry(entry)
    await loadEntries()
  }, [])

  const deleteEntry = useCallback(async (id: string) => {
    await StorageService.deleteJournalEntry(id)
    await loadEntries()
  }, [])

  return {
    entries,
    loading,
    addEntry,
    updateEntry,
    deleteEntry,
  }
}
