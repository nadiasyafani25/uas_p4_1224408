"use client"

import { useEffect } from "react"
import * as Notifications from "expo-notifications"
import { StorageService } from "../services/storage"

export const useReminderSetup = () => {
  useEffect(() => {
    requestNotificationPermissions()
    setupReminders()
  }, [])

  const requestNotificationPermissions = async () => {
    try {
      const { status } = await Notifications.requestPermissionsAsync()
      if (status !== "granted") {
        console.log("Notification permission not granted")
      }
    } catch (error) {
      console.error("Error requesting notification permissions:", error)
    }
  }

  const setupReminders = async () => {
    try {
      const settings = await StorageService.getReminderSettings()

      if (!settings.enabled) {
        await Notifications.cancelAllScheduledNotificationsAsync()
        return
      }

      // Cancel previous reminders
      await Notifications.cancelAllScheduledNotificationsAsync()

      const [hours, minutes] = settings.time.split(":").map(Number)

      if (settings.frequency === "daily") {
        // Schedule daily reminder
        await Notifications.scheduleNotificationAsync({
          content: {
            title: "Catatan Suasana Hati",
            body: "Saatnya mencatat suasana hati Anda hari ini! 😊",
            data: { type: "mood_reminder" },
            sound: "default",
          },
          trigger: {
            hour: hours,
            minute: minutes,
            repeats: true,
          },
        })
        console.log(`[v0] Daily reminder scheduled for ${hours}:${minutes}`)
      } else if (settings.frequency === "weekly") {
        // Schedule weekly reminder for Monday
        await Notifications.scheduleNotificationAsync({
          content: {
            title: "Refleksi Mingguan",
            body: "Waktunya melakukan refleksi mingguan tentang suasana hati Anda! 📝",
            data: { type: "weekly_reminder" },
            sound: "default",
          },
          trigger: {
            weekday: 2, // Monday
            hour: hours,
            minute: minutes,
            repeats: true,
          },
        })
        console.log(`[v0] Weekly reminder scheduled for Monday at ${hours}:${minutes}`)
      }
    } catch (error) {
      console.error("Error setting up reminders:", error)
    }
  }

  return { setupReminders }
}
