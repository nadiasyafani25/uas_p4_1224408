"use client"

import { useEffect } from "react"
import * as Notifications from "expo-notifications"
import { StorageService } from "../services/storage"

export const useReminder = () => {
  useEffect(() => {
    setupReminder()
  }, [])

  const setupReminder = async () => {
    const settings = await StorageService.getReminderSettings()

    if (!settings.enabled) return

    const [hours, minutes] = settings.time.split(":").map(Number)

    try {
      await Notifications.cancelAllScheduledNotificationsAsync()

      if (settings.frequency === "daily") {
        await Notifications.scheduleNotificationAsync({
          content: {
            title: "Catatan Suasana Hati",
            body: "Saatnya mencatat suasana hati Anda hari ini",
            data: { type: "mood_reminder" },
          },
          trigger: {
            hour: hours,
            minute: minutes,
            repeats: true,
          },
        })
      }
    } catch (error) {
      console.error("Error setting up reminder:", error)
    }
  }

  return { setupReminder }
}
